# 碩尹有限公司儲值網站－交接說明

## 修改網站內容

主要頁面位於 `app/page.tsx`：

- `methods`：修改信用卡及超商的金額選項。
- `cardPaymentUrls`：修改信用卡付款連結。
- `storePaymentUrls`：修改超商付款連結。
- 頁面最下方可修改公司名稱、服務條款、隱私政策及客服資訊。

網站外觀位於 `app/globals.css`，網站標題與圖示設定位於 `app/layout.tsx`。

## 在自己的電腦預覽

1. 安裝 Node.js 22 以上版本。
2. 安裝 pnpm：`npm install -g pnpm`
3. 在此資料夾執行：`pnpm install`
4. 啟動預覽：`pnpm dev`
5. 開啟畫面顯示的本機網址。

## 上傳 GitHub

1. 登入 GitHub，建立一個新的私人 Repository。
2. 把這個資料夾內的檔案上傳到 Repository。
3. 不要上傳密碼、API 金鑰或商戶密鑰；這些資料應放在發布平台的環境變數中。
4. 在 Repository 的 Settings → Collaborators 邀請技術人員，即可讓對方修改原始碼。

## 發布網站

可使用 Cloudflare Pages、Vercel，或由技術人員部署到具有固定對外 IP 的後端主機。

若要串接 SUGO API，請勿把商戶密鑰寫在 `app/page.tsx` 或其他瀏覽器端檔案中。API 必須透過後端呼叫；若 SUGO 要求 IP 白名單，後端主機還必須有固定對外 IP。
